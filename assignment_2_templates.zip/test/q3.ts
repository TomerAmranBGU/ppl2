import { ForExp, AppExp, Exp, Program } from "./L21-ast";
import { Result } from "../imp/result";

/*
Purpose: @TODO
Signature: @TODO
Type: @TODO
*/
export const for2app = (exp: ForExp): AppExp =>
    @TODO

/*
Purpose: @TODO
Signature: @TODO
Type: @TODO
*/
export const L21ToL2 = (exp: Exp | Program): Result<Exp | Program> =>
    @TODO