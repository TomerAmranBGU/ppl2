import { Exp, Program} from '../imp/L2-ast';
import { Result } from '../imp/result';

/*
Purpose: @TODO
Signature: @TODO
Type: @TODO
*/
export const l2ToJS = (exp: Exp | Program): Result<string> => 
    @TODO